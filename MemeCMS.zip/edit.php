<?php

    /*
    
    ███╗   ███╗███████╗███╗   ███╗███████╗ ██████╗███╗   ███╗███████╗
    ████╗ ████║██╔════╝████╗ ████║██╔════╝██╔════╝████╗ ████║██╔════╝
    ██╔████╔██║█████╗  ██╔████╔██║█████╗  ██║     ██╔████╔██║███████╗
    ██║╚██╔╝██║██╔══╝  ██║╚██╔╝██║██╔══╝  ██║     ██║╚██╔╝██║╚════██║
    ██║ ╚═╝ ██║███████╗██║ ╚═╝ ██║███████╗╚██████╗██║ ╚═╝ ██║███████║
    ╚═╝     ╚═╝╚══════╝╚═╝     ╚═╝╚══════╝ ╚═════╝╚═╝     ╚═╝╚══════╝
                                                                 
    */

    session_start();

    require_once 'inc/settings.php';
    require_once 'inc/db.php';

    $post_id = $_GET['id'];
    $post_id = mysqli_real_escape_string($db, $post_id);

?>

<html>

    <head>

        <title> <?php echo SITE_NAME; ?> - <?php echo 'Viewing post: ' . htmlspecialchars($post_id); ?> </title>
        <meta charset="utf-8">
        <meta name="description" content="<?php echo SITE_DESCRIPTION; ?>">
        <meta name="keywords" content="<?php echo SITE_KEYWORDS; ?>">
        <meta name="author" content="<?php echo SITE_AUTHOR; ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta property="og:title" content="<?php echo SITE_NAME; ?>">
        <meta property="og:description" content="<?php echo SITE_DESCRIPTION; ?>">
        <meta property="og:url" content="<?php echo SITE_URL; ?>">
        <meta property="og:image" content="<?php echo SITE_URL; ?>img/logo.png">
        <meta property="og:type" content="website">
        <meta property="og:site_name" content="<?php echo SITE_NAME; ?>">
        <link rel="stylesheet" href="./css/<?php echo SITE_THEME; ?>.css">

    </head>

    <body>

        <?php include 'static/header.php'; ?>

        <div class="posts">

            <?php

                if(!isset($_SESSION['username'])) {
                    header('Location: index.php');
                }

                $id = $_GET['id'];
                $id = mysqli_real_escape_string($db, $id);

                $sql = "SELECT * FROM posts WHERE id = '$id'";
                $result = mysqli_query($db, $sql);


                if($result->num_rows > 0) {

                    while($row = $result->fetch_assoc()) {

                        $post_id = $row['id'];
                        $post_title = $row['title'];
                        $post_content = $row['content'];
                        $post_author = $row['author'];
                        $post_date = $row['date'];

                        if($post_author == $_SESSION['username']) {

                            echo '

                                <form action="edit.php?id=' . $post_id . '" method="post">

                                    <input type="text" name="title" style="width: 719px;" value="' . $post_title . '"><br><br>
                                    <textarea name="content" style="resize: none; height: 331px; width: 719px;">' . $post_content . '</textarea><br><br>
                                    <input type="submit" name="submit" value="Update">

                                </form>

                            ';

                        } else {

                            echo '

                                <h3> You are not the author of this post. </h3>

                            ';

                        }

                    }

                } else {

                    echo '

                        <h3> Post not found! (404) </h3>

                    ';

                }


            ?>

        </div>

        <?php include 'static/footer.php'; ?>

    </body>

</html>

<?php


    if(isset($_POST['submit'])) {

        $title = $_POST['title'];
        $content = $_POST['content'];

        $title = mysqli_real_escape_string($db, $title);
        $content = mysqli_real_escape_string($db, $content);

        $sql = "UPDATE posts SET title = '$title', content = '$content' WHERE id = '$post_id'";
        $result = mysqli_query($db, $sql);

        if($result) {

            header('Location: index.php');

        } else {

            echo '

                <h3> Something went wrong! </h3>

            ';

        }

    }


?>