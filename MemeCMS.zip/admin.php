<?php

    /*
    
    ███╗   ███╗███████╗███╗   ███╗███████╗ ██████╗███╗   ███╗███████╗
    ████╗ ████║██╔════╝████╗ ████║██╔════╝██╔════╝████╗ ████║██╔════╝
    ██╔████╔██║█████╗  ██╔████╔██║█████╗  ██║     ██╔████╔██║███████╗
    ██║╚██╔╝██║██╔══╝  ██║╚██╔╝██║██╔══╝  ██║     ██║╚██╔╝██║╚════██║
    ██║ ╚═╝ ██║███████╗██║ ╚═╝ ██║███████╗╚██████╗██║ ╚═╝ ██║███████║
    ╚═╝     ╚═╝╚══════╝╚═╝     ╚═╝╚══════╝ ╚═════╝╚═╝     ╚═╝╚══════╝
                                                                 
    */

    session_start();

    require_once 'inc/settings.php';
    require_once 'inc/db.php';

    if(!isset($_SESSION['username'])) {
        header('Location: index.php');
    }

    // Proper role system will be added in the future (if I have time and motivation)
    if($_SESSION['username'] != 'admin') {
        header('Location: index.php');
    }

?>

<html>

    <head>

        <title> <?php echo SITE_NAME; ?> - Administrator</title>
        <meta charset="utf-8">
        <meta name="description" content="<?php echo SITE_DESCRIPTION; ?>">
        <meta name="keywords" content="<?php echo SITE_KEYWORDS; ?>">
        <meta name="author" content="<?php echo SITE_AUTHOR; ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta property="og:title" content="<?php echo SITE_NAME; ?>">
        <meta property="og:description" content="<?php echo SITE_DESCRIPTION; ?>">
        <meta property="og:url" content="<?php echo SITE_URL; ?>">
        <meta property="og:image" content="<?php echo SITE_URL; ?>img/logo.png">
        <meta property="og:type" content="website">
        <meta property="og:site_name" content="<?php echo SITE_NAME; ?>">
        <link rel="stylesheet" href="./css/<?php echo SITE_THEME; ?>.css">

    </head>

    <body>

        <?php include 'static/header.php'; ?>

        <div class="admin">

            <h3> Welcome, <?php echo $_SESSION['username']; ?>! </h3>
            <p> Edit the site settings below. </p>

            <form action="./admin.php" method="post">

                <br>
                <input title="Website name" type="text" name="site_name" placeholder="Site Name" value="<?php echo SITE_NAME; ?>" required><br>
                <input title="Website description" type="text" name="site_description" placeholder="Site Description" value="<?php echo SITE_DESCRIPTION; ?>" required><br>
                <input title="Keywords for SEO" type="text" name="site_keywords" placeholder="Site Keywords" value="<?php echo SITE_KEYWORDS; ?>" required><br>
                <input title="Website author" type="text" name="site_author" placeholder="Site Author" value="<?php echo SITE_AUTHOR; ?>" required><br>
                <input title="Site URL ending in /" type="text" name="site_url" placeholder="Site URL" value="<?php echo SITE_URL; ?>" required><br>
                <input title="Theme name (location: ./css/)" type="text" name="site_theme" placeholder="Site Theme" value="<?php echo SITE_THEME; ?>" required><br><br>
                <input title="Maintenance message" type="text" name="site_maintenance_message" placeholder="Maintenance Message" value="<?php echo SITE_MAINTENANCE_MESSAGE; ?>" required><br>
                <input title="Maintenance mode (true/false)" type="text" name="site_maintenance" placeholder="Maintenance Mode" value="<?php echo SITE_MAINTENANCE; ?>" required><br><br>
                <input type="submit" name="save" value="Save">

            </form>

            <form action="./admin.php" method="post">

            </form>

            <br>

        <?php include 'static/footer.php'; ?>

    </body>

</html>

<?php

    if(isset($_POST['save'])) {

        $site_name = htmlspecialchars($_POST['site_name']);
        $site_description = htmlspecialchars($_POST['site_description']);
        $site_keywords = htmlspecialchars($_POST['site_keywords']);
        $site_author = htmlspecialchars($_POST['site_author']);
        $site_url = htmlspecialchars($_POST['site_url']);
        $site_theme = htmlspecialchars($_POST['site_theme']);
        $maintmsg = htmlspecialchars($_POST['site_maintenance_message']);
        $maint = htmlspecialchars($_POST['site_maintenance']);

        // Edit settings.php

        $settings = file_get_contents('inc/settings.php');

        $settings = str_replace(SITE_NAME, $site_name, $settings);
        $settings = str_replace(SITE_DESCRIPTION, $site_description, $settings);
        $settings = str_replace(SITE_KEYWORDS, $site_keywords, $settings);
        $settings = str_replace(SITE_AUTHOR, $site_author, $settings); // This doesn't seem to work. Might fix later.
        $settings = str_replace(SITE_URL, $site_url, $settings);
        $settings = str_replace(SITE_THEME, $site_theme, $settings);
        $settings = str_replace(SITE_MAINTENANCE_MESSAGE, $maintmsg, $settings);
        $settings = str_replace(SITE_MAINTENANCE, $maint, $settings);

        file_put_contents('inc/settings.php', $settings);

        echo "<script>alert('Settings saved!');</script>";
        echo "<script>window.location.href = './admin.php';</script>";

    }

?>