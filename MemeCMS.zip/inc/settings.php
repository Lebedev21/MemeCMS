<?php

    /*
    
    ███╗   ███╗███████╗███╗   ███╗███████╗ ██████╗███╗   ███╗███████╗
    ████╗ ████║██╔════╝████╗ ████║██╔════╝██╔════╝████╗ ████║██╔════╝
    ██╔████╔██║█████╗  ██╔████╔██║█████╗  ██║     ██╔████╔██║███████╗
    ██║╚██╔╝██║██╔══╝  ██║╚██╔╝██║██╔══╝  ██║     ██║╚██╔╝██║╚════██║
    ██║ ╚═╝ ██║███████╗██║ ╚═╝ ██║███████╗╚██████╗██║ ╚═╝ ██║███████║
    ╚═╝     ╚═╝╚══════╝╚═╝     ╚═╝╚══════╝ ╚═════╝╚═╝     ╚═╝╚══════╝
                                                                 
    */

    error_reporting(0);

    // Basic Information //
    DEFINE('SITE_NAME', 'MemeCMS');
    DEFINE('SITE_URL', 'http://localhost/');
    DEFINE('SITE_DESCRIPTION', 'This is a MemeCMS demo site.');
    DEFINE('SITE_KEYWORDS', 'MemeCMS, Demo');
    DEFINE('SITE_AUTHOR', 'MemeCMS User');

    // Appearance //
    DEFINE('SITE_THEME', 'default');

    // Other //
    DEFINE('SITE_MAINTENANCE', 'false');
    DEFINE('SITE_MAINTENANCE_MESSAGE', 'This site is under maintenance. Come back later.');


    // DO NOT EDIT BELOW THIS LINE //

    if(SITE_MAINTENANCE == 'true') {
        include 'static/maintenance.php';
        exit;
    }

    // DO NOT EDIT ABOVE THIS LINE //

?>