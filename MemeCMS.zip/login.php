<?php

    /*
    
    ███╗   ███╗███████╗███╗   ███╗███████╗ ██████╗███╗   ███╗███████╗
    ████╗ ████║██╔════╝████╗ ████║██╔════╝██╔════╝████╗ ████║██╔════╝
    ██╔████╔██║█████╗  ██╔████╔██║█████╗  ██║     ██╔████╔██║███████╗
    ██║╚██╔╝██║██╔══╝  ██║╚██╔╝██║██╔══╝  ██║     ██║╚██╔╝██║╚════██║
    ██║ ╚═╝ ██║███████╗██║ ╚═╝ ██║███████╗╚██████╗██║ ╚═╝ ██║███████║
    ╚═╝     ╚═╝╚══════╝╚═╝     ╚═╝╚══════╝ ╚═════╝╚═╝     ╚═╝╚══════╝
                                                                 
    */

    session_start();

    require_once 'inc/settings.php';
    require_once 'inc/db.php';

    if(isset($_SESSION['username'])) {
        header('Location: index.php');
    }

?>

<html>

    <head>

        <title> <?php echo SITE_NAME; ?> - Login </title>
        <meta charset="utf-8">
        <meta name="description" content="<?php echo SITE_DESCRIPTION; ?>">
        <meta name="keywords" content="<?php echo SITE_KEYWORDS; ?>">
        <meta name="author" content="<?php echo SITE_AUTHOR; ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta property="og:title" content="<?php echo SITE_NAME; ?>">
        <meta property="og:description" content="<?php echo SITE_DESCRIPTION; ?>">
        <meta property="og:url" content="<?php echo SITE_URL; ?>">
        <meta property="og:image" content="<?php echo SITE_URL; ?>img/logo.png">
        <meta property="og:type" content="website">
        <meta property="og:site_name" content="<?php echo SITE_NAME; ?>">
        <link rel="stylesheet" href="./css/<?php echo SITE_THEME; ?>.css">

    </head>

    <body>

        <?php include 'static/header.php'; ?>

        <div class="login">

            <form action="./login.php" method="post">

                <br>
                <input type="text" name="username" placeholder="Username" required><br>
                <input type="password" name="password" placeholder="Password" required><br><br>
                <input type="submit" value="Login">

            </form>

        </div><br><br>

        <?php include 'static/footer.php'; ?>

    </body>

</html>

<?php

    if(isset($_POST['username']) && isset($_POST['password'])) {

        $username = $_POST['username'];
        $password = $_POST['password'];

        $username = mysqli_real_escape_string($db, $username);
        $password = mysqli_real_escape_string($db, $password);

        $query = "SELECT * FROM users WHERE username = '$username'";
        $result = mysqli_query($db, $query);

        if(mysqli_num_rows($result) == 1) {

            $row = mysqli_fetch_assoc($result);

            if(password_verify($password, $row['password'])) {

                $_SESSION['username'] = $username;
                header('Location: index.php');

            } else {

                echo 'Incorrect password.';

            }

        } else {

            echo 'Incorrect username.';

        }

    }

?>