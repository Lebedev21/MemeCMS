<?php

    session_start();

    require 'inc/settings.php';
    require 'inc/db.php';

    if(!isset($_SESSION['username'])) {
        header('Location: index.php');
    }

    if(isset($_GET['id'])) {
        $id = $_GET['id'];
        $id = mysqli_real_escape_string($db, $id);
        // Does post exist?
        $sql = "SELECT * FROM posts WHERE id = '$id'";
        $result = mysqli_query($db, $sql);
        if(mysqli_num_rows($result) == 0) {
            header('Location: index.php');
        } else {
            // Does post belong to logged in user?
            $sql = "SELECT * FROM posts WHERE id = '$id' AND author = '" . $_SESSION['username'] . "'";
            $result = mysqli_query($db, $sql);
            if(mysqli_num_rows($result) == 0) {
                header('Location: index.php');
            } else {
                // Delete post
                $sql = "DELETE FROM posts WHERE id = '$id'";
                $result = mysqli_query($db, $sql);
                header('Location: index.php');
            }
        }
    }

?>