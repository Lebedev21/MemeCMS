<?php

    /*
    
    ███╗   ███╗███████╗███╗   ███╗███████╗ ██████╗███╗   ███╗███████╗
    ████╗ ████║██╔════╝████╗ ████║██╔════╝██╔════╝████╗ ████║██╔════╝
    ██╔████╔██║█████╗  ██╔████╔██║█████╗  ██║     ██╔████╔██║███████╗
    ██║╚██╔╝██║██╔══╝  ██║╚██╔╝██║██╔══╝  ██║     ██║╚██╔╝██║╚════██║
    ██║ ╚═╝ ██║███████╗██║ ╚═╝ ██║███████╗╚██████╗██║ ╚═╝ ██║███████║
    ╚═╝     ╚═╝╚══════╝╚═╝     ╚═╝╚══════╝ ╚═════╝╚═╝     ╚═╝╚══════╝
                                                                 
    */

    session_start();

    require_once 'inc/settings.php';
    require_once 'inc/db.php';

?>

<html>

    <head>

        <title> <?php echo SITE_NAME; ?> - All Posts </title>
        <meta charset="utf-8">
        <meta name="description" content="<?php echo SITE_DESCRIPTION; ?>">
        <meta name="keywords" content="<?php echo SITE_KEYWORDS; ?>">
        <meta name="author" content="<?php echo SITE_AUTHOR; ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta property="og:title" content="<?php echo SITE_NAME; ?>">
        <meta property="og:description" content="<?php echo SITE_DESCRIPTION; ?>">
        <meta property="og:url" content="<?php echo SITE_URL; ?>">
        <meta property="og:image" content="<?php echo SITE_URL; ?>img/logo.png">
        <meta property="og:type" content="website">
        <meta property="og:site_name" content="<?php echo SITE_NAME; ?>">
        <link rel="stylesheet" href="./css/<?php echo SITE_THEME; ?>.css">

    </head>

    <body>

        <?php include 'static/header.php'; ?>

        <div class="posts">

            <?php

                $stmt = $db->prepare('SELECT * FROM posts ORDER BY date DESC LIMIT 25');
                $stmt->execute();
                $stmt->bind_result($id, $title, $content, $author, $date);

                while($stmt->fetch()) {
                    echo '<div class="post">';
                    echo '<h3>' . $title .  ' | Posted by ' . $author . ' on ' . $date . '</h3>';
                    echo '<p>' . substr($content, 0, 50) . '...</p> <a href="post.php?id=' . $id . '">Read More</a>';
                    echo '</div>';
                }

            ?>

            <br><br><br>
            <a href="index.php">Back to Home</a>

        </div>

        <?php include 'static/footer.php'; ?>

    </body>

</html>