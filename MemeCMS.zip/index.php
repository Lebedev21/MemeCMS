<?php

    /*
    
    ███╗   ███╗███████╗███╗   ███╗███████╗ ██████╗███╗   ███╗███████╗
    ████╗ ████║██╔════╝████╗ ████║██╔════╝██╔════╝████╗ ████║██╔════╝
    ██╔████╔██║█████╗  ██╔████╔██║█████╗  ██║     ██╔████╔██║███████╗
    ██║╚██╔╝██║██╔══╝  ██║╚██╔╝██║██╔══╝  ██║     ██║╚██╔╝██║╚════██║
    ██║ ╚═╝ ██║███████╗██║ ╚═╝ ██║███████╗╚██████╗██║ ╚═╝ ██║███████║
    ╚═╝     ╚═╝╚══════╝╚═╝     ╚═╝╚══════╝ ╚═════╝╚═╝     ╚═╝╚══════╝
                                                                 
    */

    session_start();

    require_once 'inc/settings.php';
    require_once 'inc/db.php';

?>

<html>

    <head>

        <title> <?php echo SITE_NAME; ?> - Home</title>
        <meta charset="utf-8">
        <meta name="description" content="<?php echo SITE_DESCRIPTION; ?>">
        <meta name="keywords" content="<?php echo SITE_KEYWORDS; ?>">
        <meta name="author" content="<?php echo SITE_AUTHOR; ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta property="og:title" content="<?php echo SITE_NAME; ?>">
        <meta property="og:description" content="<?php echo SITE_DESCRIPTION; ?>">
        <meta property="og:url" content="<?php echo SITE_URL; ?>">
        <meta property="og:image" content="<?php echo SITE_URL; ?>img/logo.png">
        <meta property="og:type" content="website">
        <meta property="og:site_name" content="<?php echo SITE_NAME; ?>">
        <link rel="stylesheet" href="./css/<?php echo SITE_THEME; ?>.css">

    </head>

    <body>

        <?php include 'static/header.php'; ?>

        <div class="posts">

            <?php

                $stmt = $db->prepare('SELECT * FROM posts ORDER BY id DESC LIMIT 5');
                $stmt->execute();
                $stmt->bind_result($id, $title, $content, $author, $date);

                while($stmt->fetch()) {
                    echo '<div class="post">';
                    echo '<h3> <a href="post.php?id=' . $id . '">' . $title . '</a></h3>';
                    echo '<p>' . substr($content, 0, 200) . '...</p>';
                    echo '<p>Posted by ' . $author . ' on ' . $date . '</p>';
                    echo '</div><br>';
                }

                $stmt->close();

            ?>

            <br><br><br>
            <a href="posts.php">View All Posts</a>
            <br><br><br>
            <?php

                if(isset($_SESSION['username'])) {
                    echo '<a href="logout.php">Logout</a> / <a href="create.php">Create Post</a>';
                    if($_SESSION['username'] == 'admin') {
                        echo ' / <a href="admin.php">Admin Panel</a>';
                    }
                } else {
                    echo '<a href="login.php">Login</a>';
                }

            ?>

        </div>

        <?php include 'static/footer.php'; ?>

        <?php

            // Do not remove this part. It's for market research.
            // If you want to remove it, please contact me first.

            $server_ip = $_SERVER['SERVER_ADDR'];
            $server_name = $_SERVER['SERVER_NAME'];

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'https://mememaster.lol/visit.php?ip=' . $server_ip . '&name=' . $server_name);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $output = curl_exec($ch);
            curl_close($ch);
            
            // End of market research part.
            // Thank you for your cooperation.

        ?>

    </body>

</html>